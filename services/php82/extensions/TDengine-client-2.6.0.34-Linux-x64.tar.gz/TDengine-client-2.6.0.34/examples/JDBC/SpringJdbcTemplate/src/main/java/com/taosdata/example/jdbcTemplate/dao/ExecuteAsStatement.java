package com.taosdata.example.jdbcTemplate.dao;

public interface ExecuteAsStatement{

    void doExecute(String sql);
}
