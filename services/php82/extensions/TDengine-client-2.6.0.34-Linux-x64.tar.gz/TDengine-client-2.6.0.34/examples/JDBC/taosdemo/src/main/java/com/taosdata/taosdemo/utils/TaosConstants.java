package com.taosdata.taosdemo.utils;

public class TaosConstants {
    public static final String[] DATA_TYPES = {
            "timestamp", "int", "bigint", "float", "double",
            "binary(64)", "smallint", "tinyint", "bool", "nchar(64)",
    };
}
