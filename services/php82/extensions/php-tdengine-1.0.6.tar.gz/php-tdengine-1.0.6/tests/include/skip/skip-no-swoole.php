<?php
if (!extension_loaded('swoole'))
{
    echo 'skip';
}