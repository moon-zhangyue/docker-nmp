php run-tests.php --show-diff -q $args
