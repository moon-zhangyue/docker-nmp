#!/bin/bash
php run-tests.php --show-diff -q $@
