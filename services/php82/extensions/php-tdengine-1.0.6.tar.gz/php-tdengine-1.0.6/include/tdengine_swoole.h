#pragma once

#ifdef HAVE_SWOOLE

#include "swoole_coroutine.h"
using swoole::Coroutine;

#endif
